// Q.NO :1

// function data (number1) {
//     return function(number2){
//       console.log(number1 + number2);
//     }
//}
// let result = data(5);
// result(7);


// Q.NO:2 
// function arrayFind(arr, num) {
   // base case: if array is empty, return false
//   if (arr.length === 0) {
//     return false;
//   }
//   if (arr[0] === num) {
//     return true;
//   }
   // recursive case
//   return arrayFind(arr.slice(1), num);
// }
// let myArray = [1, 2, 3, 4, 5];
// console.log(arrayFind(myArray, 9));
// console.log(arrayFind(myArray, 2));


// Q.NO:3

// function addParagraphBottom(text) {
//   const newParagraph = document.getElementById("my-para"); 
//   const content = document.createTextNode(text); 
//   newParagraph.appendChild(content); 
//   document.body.appendChild(newParagraph); 
// }

// addParagraphBottom('This is a new paragraph added through function!');

// Q.NO:4
//function addListItem(str) {
    // create a new list item element
//    let newItem = document.createElement("li");
//    let itemstr = document.createTextNode(str);
//    newItem.appendChild(itemstr);

    // get a reference to the unordered list
//    var list = document.querySelector("ul");

    // add the new item to the list
//    list.appendChild(newItem);
//}
//addListItem("Fahad");

// Q.NO: 5

 //function changeBackgroundColor(element, color,) {
 //  element.style.backgroundColor = color;  
 //}

 //let div = document.getElementById('change-color');
 //changeBackgroundColor(div, 'pink');

// Q.: 6
 //function saveObjectToLocalStorage(key, object) {
   // Convert the object to a JSON string
  // const objectJSON = JSON.stringify(object);

   // Save the JSON string to localStorage
  // localStorage.setItem(key, objectJSON);
 //}

 //const Object = {
 //   name: "Fahad",
 //   city: "Sanghar"
 //   };
 //saveObjectToLocalStorage("myKey", Object);

// Q.NO: 7 

// function saveObjectToLocalStorage(key, object) {
  
//   const objectJSON = JSON.stringify(object);

  
//   localStorage.setItem(key, objectJSON);
// }

// const myObject = { 
// name: "Fahad",
// age: 26,
// city: "Karachi",
//  };
// saveObjectToLocalStorage("myKey", myObject);


// function getObjectFromLocalStorage(key) {
 
//   const objectJSON = localStorage.getItem(key);

  
//   if (!objectJSON) {
//     return null;
//   }

  
//   return JSON.parse(objectJSON);
// }


// Question NO: 8 Solve

// function saveObjectToLocalStorage(obj) {
//   // Save each property to localStorage using property name as key and value as value
//   Object.keys(obj).forEach(key => {
//     localStorage.setItem(key, JSON.stringify(obj[key]));
//   });

//   // Retrieve the object from localStorage and return it as a new object
//   const newObj = {};
//   Object.keys(obj).forEach(key => {
//     newObj[key] = JSON.parse(localStorage.getItem(key));
//   });
//   return newObj;
// }

// const myObj = {name: 'Fahad', age: 26};
// const savedObj = saveObjectToLocalStorage(myObj);
// console.log(savedObj); 
















































